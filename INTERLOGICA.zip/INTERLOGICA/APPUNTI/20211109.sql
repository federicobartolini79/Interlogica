-- importo i csv
USE Interlogica;
GO
BULK INSERT PROPRIETARI FROM 'C:\INTERLOGICA\INPUT\INPUT_PROPRIETARI.csv'
   WITH (
      ERRORFILE = 'C:\INTERLOGICA\ERRORI_IMPORT\ERRORI_IMPORT_PROPRIETARI.CSV',
	  CHECK_CONSTRAINTS,
      FIELDTERMINATOR = ',',
      ROWTERMINATOR = '\n'
);
GO
BULK INSERT ASSICURAZIONI FROM 'C:\INTERLOGICA\INPUT\INPUT_ASSICURAZIONI.csv'
   WITH (
      ERRORFILE = 'C:\INTERLOGICA\ERRORI_IMPORT\ERRORI_IMPORT_ASSICURAZIONI.CSV',
	  CHECK_CONSTRAINTS,
      FIELDTERMINATOR = ',',
      ROWTERMINATOR = '\n'
);
GO
BULK INSERT SINISTRI FROM 'C:\INTERLOGICA\INPUT\INPUT_SINISTRI.csv'
   WITH (
      ERRORFILE = 'C:\INTERLOGICA\ERRORI_IMPORT\ERRORI_IMPORT_SINISTRI.CSV',
	  CHECK_CONSTRAINTS,
      FIELDTERMINATOR = ',',
      ROWTERMINATOR = '\n'
);
GO
BULK INSERT [AUTO] FROM 'C:\INTERLOGICA\INPUT\INPUT_AUTO.csv'
   WITH (
      ERRORFILE = 'C:\INTERLOGICA\ERRORI_IMPORT\ERRORI_IMPORT_AUTO.CSV',
	  CHECK_CONSTRAINTS,
      FIELDTERMINATOR = ',',
      ROWTERMINATOR = '\n'
);
GO
BULK INSERT AUTOCOINVOLTE FROM 'C:\INTERLOGICA\INPUT\INPUT_AUTOCOINVOLTE.csv'
   WITH (
      ERRORFILE = 'C:\INTERLOGICA\ERRORI_IMPORT\ERRORI_IMPORT_AUTOCOINVOLTE.CSV',
	  CHECK_CONSTRAINTS,
      FIELDTERMINATOR = ',',
      ROWTERMINATOR = '\n'
);
GO

-- SPOSTO I FILE DI IMPUTO RINOMINANDOLI CON TIMESTAMP
USE master;  
GO  
EXEC sp_configure 
     'show advanced option', 
     1;  
RECONFIGURE WITH OVERRIDE;
go


EXEC sp_configure 'xp_cmdshell', 1;  
GO  
RECONFIGURE;
go

EXEC xp_cmdshell 'MOVE "C:\INTERLOGICA\INPUT\INPUT_PROPRIETARI.CSV" "C:\INTERLOGICA\PROCESSED\INPUT_PROPRIETARI_%date:/=-% %time::=-%.CSV"'
EXEC xp_cmdshell 'MOVE "C:\INTERLOGICA\INPUT\INPUT_ASSICURAZIONI.CSV" "C:\INTERLOGICA\PROCESSED\INPUT_ASSICURAZIONI_%date:/=-% %time::=-%.CSV"'
EXEC xp_cmdshell 'MOVE "C:\INTERLOGICA\INPUT\INPUT_SINISTRI.CSV" "C:\INTERLOGICA\PROCESSED\INPUT_SINISTRI_%date:/=-% %time::=-%.CSV"'
EXEC xp_cmdshell 'MOVE "C:\INTERLOGICA\INPUT\INPUT_AUTO.CSV" "C:\INTERLOGICA\PROCESSED\INPUT_AUTO_%date:/=-% %time::=-%.CSV"'
EXEC xp_cmdshell 'MOVE "C:\INTERLOGICA\INPUT\INPUT_AUTOCOINVOLTE.CSV" "C:\INTERLOGICA\PROCESSED\INPUT_AUTOCOINVOLTE_%date:/=-% %time::=-%.CSV"'
;

-- eseguo query
--1--
select * from [auto] where cilindrata>2000 or potenza>120

--2--
select t0.targa,t1.nome from [auto] t0
left outer join proprietari t1 on t0.codf=t1.codf
where t0.cilindrata>2000 or t0.potenza>120

--3--
select t0.targa,t1.nome from [auto] t0
left outer join proprietari t1 on t0.codf=t1.codf
left outer join assicurazioni t2 on t0.codass=t2.codass
where (t0.cilindrata>2000 or t0.potenza>120) and t2.nome='sara'
--4--
select t0.targa,t1.nome from [auto] t0
left outer join proprietari t1 on t0.codf=t1.codf
left outer join assicurazioni t2 on t0.codass=t2.codass
inner join autocoinvolte t3 on t0.targa=t3.targa
inner join sinistri t4 on t3.cods=t4.cods
where (t0.cilindrata>2000 or t0.potenza>120) and t2.nome='sara' and t4.data='20020120'

--5--
select t0.nome,t0.sede, count(t1.targa) as NAutoAss from assicurazioni t0
left outer join [auto] t1 on t0.codass=t1.codass
group by t0.nome,t0.sede

--6--
select t0.targa, count(t1.cods) as NSinistri from [auto] t0
left outer join autocoinvolte t1 on t0.targa=t1.targa
where t0.marca='fiat'
group by t0.targa

--7--
SELECT T0.TARGA, MAX(T2.NOME) AS NomeAss, SUM(T0.IMPORTODANNO) TotDanni FROM AUTOCOINVOLTE T0
LEFT OUTER JOIN [AUTO] T1 ON T0.TARGA=T1.TARGA
LEFT OUTER JOIN ASSICURAZIONI T2 ON T1.CODASS=T2.CODASS
GROUP BY T0.TARGA 
HAVING count(t0.cods)>1

--8--
select t0.codf,t0.nome from proprietari t0
left outer join [auto] t1 on t0.codf=t1.codf
group by t0.codf,t0.nome
having count(t1.targa)>1

--9--
select targa from [auto]
where targa not in (select distinct targa from autocoinvolte t0 left outer join sinistri t1 on t0.cods=t1.cods where t1.data>'20210120')

--10--
select cods from sinistri where cods not in 
(select distinct cods from autocoinvolte t0
left outer join [auto] t1 on t0.targa=t1.targa
where t1.cilindrata<2000)

--RIVALUTAZIONE SINISTRI

insert into autocoinvolte_history
SELECT 
T0.cods              as CODS,
t0.targa             as TARGA,
t0.importodanno      as IMPORTODANNO_NORIV,
t0.importodanno*1.10 as IMPORTODANNO_RIV,
getdate()            as DATA_RIV
FROM AUTOCOINVOLTE T0
LEFT OUTER JOIN [AUTO] T1 ON T0.TARGA=T1.TARGA
LEFT OUTER JOIN PROPRIETARI T2 ON T1.CODF=T2.CODF
left outer join assicurazioni t3 on t1.codass=t3.codass
left outer join sinistri t4 on t0.cods=t4.cods
left outer join autocoinvolte_history t5 on t0.cods=t5.cods and t0.targa=t5.targa
WHERE ltrim(rtrim(T2.RESIDENZA))<>ltrim(rtrim(t3.sede)) and t4.data<'20210120' and t5.targa is null and importodanno>0


update autocoinvolte
set importodanno=importodanno_riv
from autocoinvolte t0
inner join autocoinvolte_history t1 on t0.cods=t1.cods and t0.targa=t1.targa
where importodanno_riv>0


-- seconda query per xls
select targa,nome,flagriv,importodanno_riv from 
(select  
t0.targa,
t2.nome,
case when t3.importodanno_riv>0 then 'S' 
     when t3.importodanno_riv=0 or t3.importodanno_riv is null then 'N' end as FlagRiv,
t3.importodanno_riv
from autocoinvolte t0
left outer join [auto] t1 on t0.targa=t1.targa
left outer join proprietari t2 on t1.codf=t2.codf
left outer join autocoinvolte_history t3 on t0.cods=t3.cods and t0.targa=t3.targa) p
group by targa,nome,flagriv,importodanno_riv



EXEC xp_cmdshell 'bcp INTERLOGICA.DBO.QUERY9 out C:\interlogica\output\Query9.csv -S DESKTOP-SJ4O14T\SQLEXPRESS -T -c -t,'
EXEC xp_cmdshell 'MOVE "C:\interlogica\output\Query9.csv" "C:\interlogica\output\Query9_%date:/=-% %time::=-%.CSV"'

EXEC xp_cmdshell 'bcp INTERLOGICA.DBO.Targhe_sin_riv out C:\interlogica\output\Targhe_sin_riv.csv -S DESKTOP-SJ4O14T\SQLEXPRESS -T -c -t,'
EXEC xp_cmdshell 'MOVE "C:\interlogica\output\Targhe_sin_riv.csv" "C:\interlogica\output\Targhe_sin_riv_%date:/=-% %time::=-%.CSV"'



